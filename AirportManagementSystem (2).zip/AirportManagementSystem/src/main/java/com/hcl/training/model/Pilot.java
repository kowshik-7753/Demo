package com.hcl.training.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="Pilot")
public class Pilot {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int pilotId;
	String pilotName;
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getPilotName() {
		return pilotName;
	}
	public void setPilotName(String pilotName) {
		this.pilotName = pilotName;
	}
}
