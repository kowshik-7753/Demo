package com.hcl.training;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.hcl.training.model.Admin;
import com.hcl.training.model.Hanger;
import com.hcl.training.model.Manager;
import com.hcl.training.model.Pilot;
import com.hcl.training.model.Plane;
import com.hcl.training.service.ServiceInf;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class AirportManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

	Plane plane;
	Pilot pilot;
	Hanger hanger;
	Admin admin;
	Manager manager;
	@Autowired
	ServiceInf service;

	@BeforeEach
	public void setUp() {
		plane = new Plane();
		pilot = new Pilot();
		hanger = new Hanger();
		admin = new Admin();
		manager = new Manager();
	}

	@Test
	public void testSaveAdmin() {
		admin.setFirstName("kowshik");
		admin.setGender("Male");
		admin.setLastName("k");
		admin.setVendorId("kowshik123");
		admin.setPassword("password");
		admin.setContactNumber("7095035428");
		admin.setAge(21);
		service.saveAdmin(admin);
	}

	@Test
	public void testSaveManager() {
		manager.setFirstName("sriram");
		manager.setLastName("M");
		manager.setManagerId("sri123");
		manager.setPassword("password");
		manager.setGender("Male");
		manager.setContactNumber("819203456");
		manager.setAge(21);
		service.saveManager(manager);
	}

	@Test
	public void testPlane() {
		plane.setPlaneName("kkk");
		plane.setHangerId(3);
		plane.setToLocation("Bangalore");
		plane.setFromLocation("Vishakapatname");
		service.savePlane(plane);

	}

	@Test
	public void testPlanes() {
		service.getPlanes();
	}

	@Test
	public void testPlaneById() {
		service.getPlaneById(1);
	}

	@Test
	public void testHangerById() {
		service.getHangerById(1);
	}

	@Test
	public void testPilot() {
		pilot.setPilotName("kowshik");
		service.savePilot(pilot);
	}

	@Test
	public void testHanger() {
		hanger.setHangerName("den");
		hanger.setStatus("Available");
		service.saveHanger(hanger);
	}

	@Test
	public void testgetHangers() {
		service.getHangers();
	}

}
