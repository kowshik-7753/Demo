package com.hcl.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.model.Transfer;
import com.hcl.training.service.ServiceInf;

@RestController
@RequestMapping("/bank")
public class TransferController {
	@Autowired
	ServiceInf service;

	@PostMapping("/transfer")
	public @ResponseBody String tranferAmount(@RequestBody Transfer transfer) {
		return service.transferAmount(transfer);

	}
}
