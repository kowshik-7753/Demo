package com.hcl.training.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name="Hanger")
public class Hanger {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
int hangerId;
String hangerName;
String Status;
public int getHangerId() {
	return hangerId;
}
public void setHangerId(int hangerId) {
	this.hangerId = hangerId;
}
public String getHangerName() {
	return hangerName;
}
public void setHangerName(String hangerName) {
	this.hangerName = hangerName;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
}
