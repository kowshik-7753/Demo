package com.hcl.training;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan({"com.hcl.training"})
public class SpringTestConfiguration {

}
