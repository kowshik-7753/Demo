package com.hcl.training.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.training.model.Hanger;
import com.hcl.training.model.Pilot;
import com.hcl.training.service.ServiceInf;

@RestController
@RequestMapping("/airport")
public class PilotController {
	@Autowired
	ServiceInf service;

	@PostMapping("/savePilot")
	public @ResponseBody String savePilot(@RequestBody Pilot pilot) {
		service.savePilot(pilot);
		return "{\"msg\":\" Pilot Details Added Successfully\"}";
	}
	@DeleteMapping(value = "/deletePilot/{id}")
	public @ResponseBody String deletePilotById(@PathVariable int id) {
		return service.deletePilotById(id);
	}
	@GetMapping(value = "/getPilots")
	public List<Pilot> getPilots() {
		List<Pilot> ls = service.getPilots();
		return ls;
	}
	@GetMapping(value = "/getPilot/{id}")
	public @ResponseBody Optional getPilotById(@PathVariable int id) {
		Optional<Pilot>op=service.getPilotById(id);
		if(op.isPresent())
			return op;
		else {
			Optional<String>op1=Optional.ofNullable("Pilot Not Found");
			return op1;
		}
	}

}
